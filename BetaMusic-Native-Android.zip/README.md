# ẞetaMusic Native para Android

Proyecto Android nativo independiente, diseñado a partir de las referencias visuales proporcionadas. Utiliza Kotlin, vistas nativas de Android y AndroidX Media3/ExoPlayer. No utiliza Electron, HTML, CSS ni una WebView para la interfaz.

## Incluye

- Interfaz oscura inspirada en los reproductores musicales de Samsung, con identidad propia de ẞetaMusic.
- Biblioteca local basada en MediaStore: pistas, álbumes y artistas.
- Carátulas si Android expone el arte del álbum en MediaStore.
- Minirreproductor fijo en la biblioteca.
- Pantalla de reproducción completa con fondo tonal tomado de la carátula, progreso y duración.
- Reproducción, pausa, anterior, siguiente, aleatorio y repetición.
- Reproducción en segundo plano mediante `MediaSessionService`, con integración con controles multimedia compatibles.
- Favoritos persistentes, listas personalizadas, cola de reproducción, búsqueda e información de pista.
- Permiso de audio para Android 13 y versiones posteriores, con compatibilidad con Android anteriores.

## Requisitos para compilar

- Java 17.
- Android SDK Platform 35 y Build Tools 35.0.0.
- Gradle 8.9.
- Conexión a Internet para resolver las dependencias de Gradle.

El flujo incluido en `.github/workflows/android.yml` instala las herramientas en GitHub Actions y crea un APK de depuración.

## Compilar con GitHub Actions

1. Sube los archivos de este proyecto al nivel raíz de un repositorio (la carpeta `app` debe quedar en la raíz del repositorio junto a `settings.gradle.kts`).
2. Conserva `.github/workflows/android.yml` en la ubicación exacta indicada.
3. Abre la pestaña **Actions**, selecciona **Build BetaMusic Native APK** y pulsa **Run workflow**.
4. Cuando la ejecución termine en verde, abre la ejecución y descarga el artefacto `BetaMusic-Native-APK`.
5. Extrae ese ZIP y abre `app-debug.apk` en tu teléfono.

Si GitHub permite subir solo un archivo desde el navegador del teléfono, puedes subir `BetaMusic-Native-Android.zip` y copiar el contenido de `GITHUB-WORKFLOW-FOR-UPLOADED-ZIP.yml` a `.github/workflows/build-android.yml`. Ese flujo extrae el archivo y compila el proyecto de forma automática. En ese caso, el ZIP debe permanecer en la raíz del repositorio y mantener ese nombre exacto.

## Alcance de la versión inicial

Este ZIP es el código fuente de una primera versión nativa. El proyecto incluye la automatización de compilación, pero no incluye un APK previamente compilado ni una prueba en un dispositivo real. Hay que compilarlo en GitHub Actions y probar el resultado en el teléfono. El panel de ecualizador se abre solo si el sistema dispone de uno compatible; si no, la aplicación informa que no está disponible.

## Identificadores

- Nombre visible: `ẞetaMusic`
- `applicationId`: `studio.beta.music`
- Paquete Kotlin: `studio.beta.music`
- Versión inicial: `1.0-native`
