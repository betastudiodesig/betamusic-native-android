# Keep the default Android and Media3 consumer rules.
