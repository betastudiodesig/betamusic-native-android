package studio.beta.music

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.widget.ImageView
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors

object ArtworkLoader {
    private val executor = Executors.newFixedThreadPool(2)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val cache = object : android.util.LruCache<String, Bitmap>(8 * 1024) {
        override fun sizeOf(key: String, bitmap: Bitmap): Int = bitmap.byteCount / 1024
    }

    fun load(view: ImageView, path: String?) {
        view.setImageResource(R.drawable.ic_placeholder)
        view.tag = path
        if (path.isNullOrBlank()) return
        cache.get(path)?.let {
            view.setImageBitmap(it)
            return
        }
        executor.execute {
            val bitmap = try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(path, bounds)
                val sample = maxOf(1, minOf(bounds.outWidth / 256, bounds.outHeight / 256))
                val options = BitmapFactory.Options().apply { inSampleSize = sample }
                BitmapFactory.decodeFile(path, options)
            } catch (_: Exception) { null }
            if (bitmap != null) cache.put(path, bitmap)
            mainHandler.post {
                if (view.tag == path) {
                    if (bitmap != null) view.setImageBitmap(bitmap)
                    else view.setImageResource(R.drawable.ic_placeholder)
                }
            }
        }
    }
}
