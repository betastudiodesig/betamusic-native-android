package studio.beta.music

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CollectionAdapter(
    private val onClick: (MusicCollection) -> Unit
) : RecyclerView.Adapter<CollectionAdapter.CollectionHolder>() {
    private var items: List<MusicCollection> = emptyList()

    fun submit(items: List<MusicCollection>) {
        this.items = items
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CollectionHolder =
        CollectionHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_collection, parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: CollectionHolder, position: Int) {
        val collection = items[position]
        holder.title.text = collection.title
        holder.subtitle.text = collection.subtitle
        ArtworkLoader.load(holder.artwork, collection.artworkPath)
        holder.itemView.setOnClickListener { onClick(collection) }
    }

    class CollectionHolder(view: View) : RecyclerView.ViewHolder(view) {
        val artwork: ImageView = view.findViewById(R.id.collectionArtwork)
        val title: TextView = view.findViewById(R.id.collectionTitle)
        val subtitle: TextView = view.findViewById(R.id.collectionSubtitle)
    }
}
