package studio.beta.music

import android.Manifest
import android.content.ComponentName
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.InputType
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.common.util.concurrent.ListenableFuture
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var trackRecycler: RecyclerView
    private lateinit var collectionsRecycler: RecyclerView
    private lateinit var featuredSection: View
    private lateinit var featuredCollections: LinearLayout
    private lateinit var emptyState: View
    private lateinit var emptyTitle: TextView
    private lateinit var emptyMessage: TextView
    private lateinit var listSectionTitle: TextView
    private lateinit var miniPlayer: View
    private lateinit var miniArtwork: ImageView
    private lateinit var miniTitle: TextView
    private lateinit var miniArtist: TextView
    private lateinit var miniPlayPause: TextView
    private lateinit var trackAdapter: TrackAdapter
    private lateinit var collectionAdapter: CollectionAdapter

    private val allTracks = mutableListOf<MusicTrack>()
    private var visibleTracks: List<MusicTrack> = emptyList()
    private var controller: MediaController? = null
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var currentTab = "songs"
    private var activeFilterIds: Set<Long>? = null
    private var activeFilterTitle: String? = null
    private var searchQuery = ""

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) loadLibrary() else {
            updateEmpty("Permiso necesario", "Para mostrar tus canciones, permite el acceso a los archivos de audio.")
        }
    }

    private val playerListener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            runOnUiThread { updateMiniPlayer() }
        }
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            val id = mediaItem?.mediaId?.toLongOrNull()
            if (id != null) MusicPreferences.markRecent(this@MainActivity, id)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.BLACK
        val contentRoot = findViewById<View>(R.id.mainRoot)
        val initialLeft = contentRoot.paddingLeft
        val initialTop = contentRoot.paddingTop
        val initialRight = contentRoot.paddingRight
        val initialBottom = contentRoot.paddingBottom
        ViewCompat.setOnApplyWindowInsetsListener(contentRoot) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(initialLeft + bars.left, initialTop + bars.top, initialRight + bars.right, initialBottom + bars.bottom)
            insets
        }
        ViewCompat.requestApplyInsets(contentRoot)
        bindViews()
        setupLists()
        setupTabs()
        findViewById<View>(R.id.searchButton).setOnClickListener { showSearchDialog() }
        findViewById<View>(R.id.moreButton).setOnClickListener { showMainMenu(it) }
        findViewById<View>(R.id.createPlaylistButton).setOnClickListener { showCreatePlaylistDialog() }
        findViewById<View>(R.id.retryButton).setOnClickListener { requestOrLoadLibrary() }
        miniPlayer.setOnClickListener { openPlayer() }
        findViewById<View>(R.id.miniTextArea).setOnClickListener { openPlayer() }
        miniArtwork.setOnClickListener { openPlayer() }
        miniPlayPause.setOnClickListener { togglePlayback() }
        findViewById<View>(R.id.miniPrevious).setOnClickListener { controller?.seekToPreviousMediaItem() }
        findViewById<View>(R.id.miniNext).setOnClickListener { controller?.seekToNextMediaItem() }
        findViewById<View>(R.id.miniQueue).setOnClickListener { showQueueDialog() }
        connectToPlayback()
        requestOrLoadLibrary()
        renderScreen()
    }

    private fun bindViews() {
        trackRecycler = findViewById(R.id.tracksRecycler)
        collectionsRecycler = findViewById(R.id.collectionsRecycler)
        featuredSection = findViewById(R.id.featuredSection)
        featuredCollections = findViewById(R.id.featuredCollections)
        emptyState = findViewById(R.id.emptyState)
        emptyTitle = findViewById(R.id.emptyTitle)
        emptyMessage = findViewById(R.id.emptyMessage)
        listSectionTitle = findViewById(R.id.listSectionTitle)
        miniPlayer = findViewById(R.id.miniPlayer)
        miniArtwork = findViewById(R.id.miniArtwork)
        miniTitle = findViewById(R.id.miniTitle)
        miniArtist = findViewById(R.id.miniArtist)
        miniPlayPause = findViewById(R.id.miniPlayPause)
    }

    private fun setupLists() {
        trackAdapter = TrackAdapter(
            onSelect = { index ->
                val current = visibleTracks
                if (index in current.indices) playTrackList(current, index)
            },
            onMore = { track, view -> showTrackMenu(track, view) }
        )
        collectionAdapter = CollectionAdapter(::openCollection)
        trackRecycler.layoutManager = LinearLayoutManager(this)
        trackRecycler.adapter = trackAdapter
        collectionsRecycler.layoutManager = LinearLayoutManager(this)
        collectionsRecycler.adapter = collectionAdapter
        trackRecycler.setHasFixedSize(true)
        collectionsRecycler.setHasFixedSize(true)
    }

    private fun setupTabs() {
        findViewById<View>(R.id.tabPlaylists).setOnClickListener { currentTab = "playlists"; activeFilterIds = null; activeFilterTitle = null; renderScreen() }
        findViewById<View>(R.id.tabSongs).setOnClickListener { currentTab = "songs"; activeFilterIds = null; activeFilterTitle = null; searchQuery = ""; renderScreen() }
        findViewById<View>(R.id.tabAlbums).setOnClickListener { currentTab = "albums"; activeFilterIds = null; activeFilterTitle = null; renderScreen() }
        findViewById<View>(R.id.tabArtists).setOnClickListener { currentTab = "artists"; activeFilterIds = null; activeFilterTitle = null; renderScreen() }
        findViewById<View>(R.id.tabFavorites).setOnClickListener { currentTab = "favorites"; activeFilterIds = null; activeFilterTitle = null; renderScreen() }
    }

    private fun requestOrLoadLibrary() {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            loadLibrary()
        } else {
            permissionLauncher.launch(permission)
        }
    }

    private fun loadLibrary() {
        allTracks.clear()
        val audioUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.ALBUM_ID
        )
        val albumArtCache = mutableMapOf<Long, String?>()
        try {
            contentResolver.query(
                audioUri,
                projection,
                "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} > 1000",
                null,
                "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val albumId = cursor.getLong(albumIdCol)
                    if (!albumArtCache.containsKey(albumId)) albumArtCache[albumId] = findAlbumArtwork(albumId)
                    allTracks.add(
                        MusicTrack(
                            id = id,
                            title = cursor.getString(titleCol)?.takeIf { it.isNotBlank() } ?: "Pista sin título",
                            artist = cursor.getString(artistCol)?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: "Artista desconocido",
                            album = cursor.getString(albumCol)?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: "Álbum desconocido",
                            durationMs = cursor.getLong(durationCol),
                            albumId = albumId,
                            uri = ContentUris.withAppendedId(audioUri, id),
                            artworkPath = albumArtCache[albumId]
                        )
                    )
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo leer la biblioteca: ${e.localizedMessage ?: "error desconocido"}", Toast.LENGTH_LONG).show()
        }
        renderScreen()
        updateMiniPlayer()
    }

    private fun findAlbumArtwork(albumId: Long): String? {
        if (albumId <= 0) return null
        return try {
            val projection = arrayOf(MediaStore.Audio.Albums.ALBUM_ART)
            contentResolver.query(
                MediaStore.Audio.Albums.EXTERNAL_CONTENT_URI,
                projection,
                "${MediaStore.Audio.Albums._ID} = ?",
                arrayOf(albumId.toString()),
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            }
        } catch (_: Exception) { null }
    }

    private fun renderScreen() {
        val tabIds = mapOf(
            "playlists" to R.id.tabPlaylists,
            "songs" to R.id.tabSongs,
            "albums" to R.id.tabAlbums,
            "artists" to R.id.tabArtists,
            "favorites" to R.id.tabFavorites
        )
        tabIds.forEach { (tab, id) ->
            val label = findViewById<TextView>(id)
            val selected = tab == currentTab
            label.setTextColor(if (selected) 0xFFF7F5F4.toInt() else 0xFF8F8B90.toInt())
            label.textSize = if (selected) 22f else 15f
        }

        featuredSection.visibility = if (currentTab == "playlists") View.VISIBLE else View.GONE
        featuredCollections.removeAllViews()
        if (currentTab == "playlists") {
            addFeatured("Últimas escuchadas", MusicPreferences.recentIds(this), "recent")
            addFeatured("Pistas favoritas", MusicPreferences.favorites(this).toList(), "favorites")
        }

        val useCollections = currentTab == "playlists" || currentTab == "albums" || currentTab == "artists"
        trackRecycler.visibility = if (useCollections) View.GONE else View.VISIBLE
        collectionsRecycler.visibility = if (useCollections) View.VISIBLE else View.GONE
        listSectionTitle.visibility = if (currentTab == "favorites" || currentTab == "playlists" ||
            currentTab == "albums" || currentTab == "artists" || activeFilterTitle != null) View.VISIBLE else View.GONE

        if (currentTab == "playlists") {
            listSectionTitle.text = "Tus listas"
            val custom = MusicPreferences.playlistNames(this).map { name ->
                val ids = MusicPreferences.playlistTrackIds(this, name)
                val first = allTracks.firstOrNull { ids.contains(it.id) }
                MusicCollection(name, "${ids.size} pistas", "playlist", name, first?.artworkPath)
            }
            collectionAdapter.submit(custom)
            emptyState.visibility = View.GONE
            return
        }

        if (currentTab == "albums") {
            listSectionTitle.text = "Álbumes"
            val albums = allTracks.groupBy { it.album }.map { (album, tracks) ->
                MusicCollection(album, "${tracks.size} pistas", "album", album, tracks.firstOrNull()?.artworkPath)
            }.sortedBy { it.title.lowercase(Locale.getDefault()) }
            collectionAdapter.submit(albums)
            showCollectionEmpty(albums.isEmpty(), "No hay álbumes", "Los álbumes que encuentre en tu música aparecerán aquí.")
            return
        }

        if (currentTab == "artists") {
            listSectionTitle.text = "Artistas"
            val artists = allTracks.groupBy { it.artist }.map { (artist, tracks) ->
                MusicCollection(artist, "${tracks.size} pistas", "artist", artist, tracks.firstOrNull()?.artworkPath)
            }.sortedBy { it.title.lowercase(Locale.getDefault()) }
            collectionAdapter.submit(artists)
            showCollectionEmpty(artists.isEmpty(), "No hay artistas", "Los artistas aparecerán cuando se detecte música en el teléfono.")
            return
        }

        val favorites = MusicPreferences.favorites(this)
        val recent = MusicPreferences.recentIds(this)
        var filtered = when {
            currentTab == "favorites" -> allTracks.filter { favorites.contains(it.id) }
            activeFilterIds != null -> allTracks.filter { activeFilterIds!!.contains(it.id) }
            else -> allTracks.toList()
        }
        if (searchQuery.isNotBlank()) {
            filtered = filtered.filter {
                it.title.contains(searchQuery, true) ||
                    it.artist.contains(searchQuery, true) ||
                    it.album.contains(searchQuery, true)
            }
        }
        if (activeFilterTitle != null) listSectionTitle.text = activeFilterTitle
        else listSectionTitle.text = if (currentTab == "favorites") "Pistas favoritas" else "Todas las pistas"
        visibleTracks = filtered
        trackAdapter.submit(filtered)
        emptyState.visibility = if (filtered.isEmpty()) View.VISIBLE else View.GONE
        emptyTitle.text = when {
            currentTab == "favorites" -> "Aún no tienes favoritas"
            searchQuery.isNotBlank() -> "No se encontraron pistas"
            allTracks.isEmpty() -> "Tu música aparecerá aquí"
            else -> "Esta colección está vacía"
        }
        emptyMessage.text = when {
            allTracks.isEmpty() -> "Permite el acceso a archivos de audio o coloca música en el teléfono."
            currentTab == "favorites" -> "Usa el menú de una canción o el corazón del reproductor para guardarla."
            searchQuery.isNotBlank() -> "Prueba con otro título, artista o álbum."
            else -> "Añade canciones desde el menú de opciones."
        }
        // Recent list is intentionally surfaced as a collection rather than another permanent tab.
        @Suppress("UNUSED_VARIABLE") val unusedRecent = recent
    }

    private fun showCollectionEmpty(isEmpty: Boolean, title: String, message: String) {
        emptyState.visibility = if (isEmpty) View.VISIBLE else View.GONE
        emptyTitle.text = title
        emptyMessage.text = message
    }

    private fun addFeatured(title: String, ids: List<Long>, kind: String) {
        val card = layoutInflater.inflate(R.layout.item_featured_collection, featuredCollections, false)
        card.findViewById<TextView>(R.id.featuredTitle).text = title
        card.findViewById<TextView>(R.id.featuredSubtitle).text = "${ids.size} pistas"
        val art = allTracks.firstOrNull { ids.contains(it.id) }?.artworkPath
        ArtworkLoader.load(card.findViewById(R.id.featuredArtwork), art)
        card.setOnClickListener {
            currentTab = "songs"
            activeFilterIds = ids.toSet()
            activeFilterTitle = title
            searchQuery = ""
            renderScreen()
        }
        featuredCollections.addView(card)
    }

    private fun openCollection(collection: MusicCollection) {
        val ids: Set<Long>? = when (collection.kind) {
            "playlist" -> MusicPreferences.playlistTrackIds(this, collection.key)
            "album" -> allTracks.filter { it.album == collection.key }.map { it.id }.toSet()
            "artist" -> allTracks.filter { it.artist == collection.key }.map { it.id }.toSet()
            else -> emptySet()
        }
        currentTab = "songs"
        activeFilterIds = ids
        activeFilterTitle = collection.title
        searchQuery = ""
        renderScreen()
    }

    private fun showSearchDialog() {
        val input = EditText(this).apply {
            hint = "Canción, artista o álbum"
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
            setText(searchQuery)
            setSelection(text.length)
        }
        AlertDialog.Builder(this)
            .setTitle("Buscar en tu música")
            .setView(input)
            .setPositiveButton("Buscar") { _, _ ->
                searchQuery = input.text.toString().trim()
                currentTab = "songs"
                activeFilterIds = null
                activeFilterTitle = if (searchQuery.isNotBlank()) "Resultados de búsqueda" else null
                renderScreen()
            }
            .setNeutralButton("Limpiar") { _, _ ->
                searchQuery = ""
                activeFilterIds = null
                activeFilterTitle = null
                currentTab = "songs"
                renderScreen()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showMainMenu(anchor: View) {
        PopupMenu(this, anchor).apply {
            menu.add("Actualizar biblioteca")
            menu.add("Crear lista de reproducción")
            menu.add("Acerca de ẞetaMusic")
            setOnMenuItemClickListener { item ->
                when (item.title.toString()) {
                    "Actualizar biblioteca" -> loadLibrary()
                    "Crear lista de reproducción" -> showCreatePlaylistDialog()
                    else -> AlertDialog.Builder(this@MainActivity)
                        .setTitle("ẞetaMusic Native")
                        .setMessage("Reproductor de música nativo para Android. Kotlin + AndroidX Media3.")
                        .setPositiveButton("Cerrar", null).show()
                }
                true
            }
            show()
        }
    }

    private fun showCreatePlaylistDialog() {
        val input = EditText(this).apply {
            hint = "Nombre de la lista"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setSingleLine(true)
        }
        AlertDialog.Builder(this)
            .setTitle("Nueva lista")
            .setView(input)
            .setPositiveButton("Crear") { _, _ ->
                val name = input.text?.toString().orEmpty().trim()
                if (MusicPreferences.createPlaylist(this, name)) {
                    currentTab = "playlists"
                    renderScreen()
                    Toast.makeText(this, "Lista creada", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Escribe un nombre nuevo para la lista.", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showTrackMenu(track: MusicTrack, anchor: View) {
        PopupMenu(this, anchor).apply {
            menu.add("Reproducir ahora")
            menu.add("Reproducir a continuación")
            menu.add(if (MusicPreferences.isFavorite(this@MainActivity, track.id)) "Quitar de favoritas" else "Añadir a favoritas")
            menu.add("Añadir a lista")
            menu.add("Información de pista")
            setOnMenuItemClickListener { item ->
                when (item.title.toString()) {
                    "Reproducir ahora" -> {
                        val list = visibleTracks.ifEmpty { allTracks }
                        val index = list.indexOfFirst { it.id == track.id }
                        playTrackList(if (index >= 0) list else listOf(track), index.coerceAtLeast(0))
                    }
                    "Reproducir a continuación" -> enqueue(track)
                    "Añadir a favoritas", "Quitar de favoritas" -> {
                        MusicPreferences.toggleFavorite(this@MainActivity, track.id)
                        renderScreen()
                    }
                    "Añadir a lista" -> showPlaylistChooser(track)
                    else -> showTrackInfo(track)
                }
                true
            }
            show()
        }
    }

    private fun showPlaylistChooser(track: MusicTrack) {
        val names = MusicPreferences.playlistNames(this)
        if (names.isEmpty()) {
            AlertDialog.Builder(this).setTitle("No hay listas")
                .setMessage("Primero crea una lista de reproducción.")
                .setPositiveButton("Crear lista") { _, _ -> showCreatePlaylistDialog() }
                .setNegativeButton("Cancelar", null).show()
            return
        }
        AlertDialog.Builder(this).setTitle("Añadir a lista")
            .setItems(names.toTypedArray()) { _, which ->
                MusicPreferences.addToPlaylist(this, names[which], track.id)
                Toast.makeText(this, "Añadida a ${names[which]}", Toast.LENGTH_SHORT).show()
                renderScreen()
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun showTrackInfo(track: MusicTrack) {
        AlertDialog.Builder(this)
            .setTitle(track.title)
            .setMessage("Artista: ${track.artist}\nÁlbum: ${track.album}\nDuración: ${TimeFormatter.format(track.durationMs)}")
            .setPositiveButton("Cerrar", null).show()
    }

    private fun playTrackList(list: List<MusicTrack>, index: Int) {
        val player = controller
        if (player == null) {
            Toast.makeText(this, "El reproductor se está iniciando. Inténtalo de nuevo.", Toast.LENGTH_SHORT).show()
            return
        }
        player.setMediaItems(list.map { it.asMediaItem() }, index.coerceIn(list.indices), 0L)
        player.prepare()
        player.play()
        list.getOrNull(index)?.let { MusicPreferences.markRecent(this, it.id) }
        updateMiniPlayer()
    }

    private fun enqueue(track: MusicTrack) {
        val player = controller
        if (player == null) return
        player.addMediaItem(track.asMediaItem())
        Toast.makeText(this, "Añadida a la cola", Toast.LENGTH_SHORT).show()
    }

    private fun connectToPlayback() {
        val token = SessionToken(this, ComponentName(this, MusicPlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        controllerFuture = future
        future.addListener({
            try {
                controller = future.get()
                controller?.addListener(playerListener)
                updateMiniPlayer()
            } catch (_: Exception) {
                Toast.makeText(this, "No se pudo iniciar el motor de audio.", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun updateMiniPlayer() {
        val player = controller
        val metadata = player?.currentMediaMetadata
        if (player == null || player.currentMediaItem == null) {
            miniPlayer.visibility = View.GONE
            return
        }
        miniPlayer.visibility = View.VISIBLE
        miniTitle.text = metadata?.title?.toString()?.takeIf { it.isNotBlank() } ?: "Pista desconocida"
        miniArtist.text = metadata?.artist?.toString()?.takeIf { it.isNotBlank() } ?: "Artista desconocido"
        val path = player.currentMediaItem?.mediaMetadata?.artworkUri?.path
        ArtworkLoader.load(miniArtwork, path)
        miniPlayPause.text = if (player.isPlaying) "Ⅱ" else "▶"
    }

    private fun togglePlayback() {
        controller?.let {
            if (it.isPlaying) it.pause() else {
                if (it.mediaItemCount == 0 && allTracks.isNotEmpty()) playTrackList(allTracks, 0)
                else it.play()
            }
            updateMiniPlayer()
        }
    }

    private fun openPlayer() {
        if (controller?.currentMediaItem == null) {
            if (allTracks.isNotEmpty()) playTrackList(allTracks, 0)
            else {
                Toast.makeText(this, "Primero busca música en el teléfono.", Toast.LENGTH_SHORT).show()
                return
            }
        }
        startActivity(Intent(this, PlayerActivity::class.java))
    }

    private fun showQueueDialog() {
        val player = controller ?: return
        if (player.mediaItemCount == 0) return
        val titles = (0 until player.mediaItemCount).map { index ->
            val item = player.getMediaItemAt(index)
            val title = item.mediaMetadata.title?.toString() ?: item.mediaId
            val artist = item.mediaMetadata.artist?.toString().orEmpty()
            if (index == player.currentMediaItemIndex) "▶  $title — $artist" else "$title — $artist"
        }
        AlertDialog.Builder(this).setTitle("Cola de reproducción")
            .setItems(titles.toTypedArray()) { _, which ->
                player.seekToDefaultPosition(which)
                player.play()
            }.setPositiveButton("Cerrar", null).show()
    }

    private fun updateEmpty(title: String, message: String) {
        emptyState.visibility = View.VISIBLE
        emptyTitle.text = title
        emptyMessage.text = message
    }

    override fun onResume() {
        super.onResume()
        updateMiniPlayer()
    }

    override fun onDestroy() {
        controller?.removeListener(playerListener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
        super.onDestroy()
    }
}
