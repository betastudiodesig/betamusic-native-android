package studio.beta.music

import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata

data class MusicTrack(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val albumId: Long,
    val uri: Uri,
    val artworkPath: String?
) {
    fun asMediaItem(): MediaItem {
        val metadata = MediaMetadata.Builder()
            .setTitle(title)
            .setArtist(artist)
            .setAlbumTitle(album)
            .apply {
                if (!artworkPath.isNullOrBlank()) {
                    setArtworkUri(Uri.fromFile(java.io.File(artworkPath)))
                }
            }
            .build()
        return MediaItem.Builder()
            .setMediaId(id.toString())
            .setUri(uri)
            .setMediaMetadata(metadata)
            .build()
    }
}

data class MusicCollection(
    val title: String,
    val subtitle: String,
    val kind: String,
    val key: String,
    val artworkPath: String? = null
)

object MusicPreferences {
    private const val PREFS = "beta_music_native"
    private const val FAVORITES = "favorites"
    private const val RECENT = "recent_ids"
    private const val PLAYLIST_NAMES = "playlist_names"

    fun isFavorite(activity: android.content.Context, id: Long): Boolean =
        prefs(activity).getStringSet(FAVORITES, mutableSetOf<String>()).orEmpty().contains(id.toString())

    fun favorites(activity: android.content.Context): Set<Long> =
        prefs(activity).getStringSet(FAVORITES, mutableSetOf<String>()).orEmpty()
            .mapNotNull { it.toLongOrNull() }.toSet()

    fun toggleFavorite(activity: android.content.Context, id: Long): Boolean {
        val prefs = prefs(activity)
        val values = prefs.getStringSet(FAVORITES, mutableSetOf<String>()).orEmpty().toMutableSet()
        val nowFavorite: Boolean
        if (values.contains(id.toString())) {
            values.remove(id.toString())
            nowFavorite = false
        } else {
            values.add(id.toString())
            nowFavorite = true
        }
        prefs.edit().putStringSet(FAVORITES, values).apply()
        return nowFavorite
    }

    fun recentIds(activity: android.content.Context): List<Long> =
        prefs(activity).getString(RECENT, "").orEmpty()
            .split(",").mapNotNull { it.toLongOrNull() }

    fun markRecent(activity: android.content.Context, id: Long) {
        val ids = (listOf(id) + recentIds(activity).filterNot { it == id }).take(100)
        prefs(activity).edit().putString(RECENT, ids.joinToString(",")).apply()
    }

    fun playlistNames(activity: android.content.Context): List<String> =
        prefs(activity).getStringSet(PLAYLIST_NAMES, mutableSetOf<String>()).orEmpty().toList().sortedBy { it.lowercase() }

    fun createPlaylist(activity: android.content.Context, name: String): Boolean {
        val clean = name.trim()
        if (clean.isEmpty()) return false
        val prefs = prefs(activity)
        val names = prefs.getStringSet(PLAYLIST_NAMES, mutableSetOf<String>()).orEmpty().toMutableSet()
        if (names.any { it.equals(clean, ignoreCase = true) }) return false
        names.add(clean)
        prefs.edit()
            .putStringSet(PLAYLIST_NAMES, names)
            .putStringSet(playlistKey(clean), mutableSetOf<String>())
            .apply()
        return true
    }

    fun playlistTrackIds(activity: android.content.Context, name: String): Set<Long> =
        prefs(activity).getStringSet(playlistKey(name), mutableSetOf<String>()).orEmpty()
            .mapNotNull { it.toLongOrNull() }.toSet()

    fun addToPlaylist(activity: android.content.Context, name: String, id: Long) {
        val prefs = prefs(activity)
        val values = prefs.getStringSet(playlistKey(name), mutableSetOf<String>()).orEmpty().toMutableSet()
        values.add(id.toString())
        prefs.edit().putStringSet(playlistKey(name), values).apply()
    }

    private fun playlistKey(name: String) = "playlist_${name.hashCode()}"

    private fun prefs(context: android.content.Context) =
        context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE)
}

object TimeFormatter {
    fun format(ms: Long): String {
        if (ms <= 0L) return "0:00"
        val seconds = ms / 1000L
        return if (seconds >= 3600) {
            String.format(java.util.Locale.getDefault(), "%d:%02d:%02d", seconds / 3600, (seconds % 3600) / 60, seconds % 60)
        } else {
            String.format(java.util.Locale.getDefault(), "%d:%02d", seconds / 60, seconds % 60)
        }
    }
}
