package studio.beta.music

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.audiofx.AudioEffect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.palette.graphics.Palette
import com.google.common.util.concurrent.ListenableFuture

class PlayerActivity : AppCompatActivity() {
    private var controller: MediaController? = null
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private lateinit var root: View
    private lateinit var artwork: ImageView
    private lateinit var title: TextView
    private lateinit var artist: TextView
    private lateinit var playPause: TextView
    private lateinit var favorite: TextView
    private lateinit var shuffle: TextView
    private lateinit var repeat: TextView
    private lateinit var seekBar: SeekBar
    private lateinit var elapsed: TextView
    private lateinit var duration: TextView
    private var userSeeking = false

    private val handler = Handler(Looper.getMainLooper())
    private val progressTask = object : Runnable {
        override fun run() {
            updatePlaybackProgress()
            handler.postDelayed(this, 450)
        }
    }

    private val playerListener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) { updateUi() }
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { updateUi() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.BLACK
        root = findViewById(R.id.playerRoot)
        val initialLeft = root.paddingLeft
        val initialTop = root.paddingTop
        val initialRight = root.paddingRight
        val initialBottom = root.paddingBottom
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(initialLeft + bars.left, initialTop + bars.top, initialRight + bars.right, initialBottom + bars.bottom)
            insets
        }
        ViewCompat.requestApplyInsets(root)
        artwork = findViewById(R.id.playerArtwork)
        title = findViewById(R.id.playerTitle)
        artist = findViewById(R.id.playerArtist)
        playPause = findViewById(R.id.playerPlayPause)
        favorite = findViewById(R.id.playerFavorite)
        shuffle = findViewById(R.id.playerShuffle)
        repeat = findViewById(R.id.playerRepeat)
        seekBar = findViewById(R.id.playerSeekBar)
        elapsed = findViewById(R.id.playerElapsed)
        duration = findViewById(R.id.playerDuration)

        findViewById<View>(R.id.playerCollapse).setOnClickListener { finish() }
        findViewById<View>(R.id.playerPrevious).setOnClickListener { controller?.seekToPreviousMediaItem() }
        findViewById<View>(R.id.playerNext).setOnClickListener { controller?.seekToNextMediaItem() }
        playPause.setOnClickListener { togglePlayback() }
        shuffle.setOnClickListener { toggleShuffle() }
        repeat.setOnClickListener { toggleRepeat() }
        favorite.setOnClickListener { toggleFavorite() }
        findViewById<View>(R.id.playerQueue).setOnClickListener { showQueueDialog() }
        findViewById<View>(R.id.playerAdd).setOnClickListener { showPlaylistChooser() }
        findViewById<View>(R.id.playerVolume).setOnClickListener { adjustVolume() }
        findViewById<View>(R.id.playerEqualizer).setOnClickListener { openEqualizer() }
        findViewById<View>(R.id.playerMore).setOnClickListener { showMore(it) }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) elapsed.text = TimeFormatter.format(progress.toLong())
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) { userSeeking = true }
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                controller?.seekTo((seekBar?.progress ?: 0).toLong())
                userSeeking = false
            }
        })
        connectToPlayback()
    }

    private fun connectToPlayback() {
        val token = SessionToken(this, ComponentName(this, MusicPlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        controllerFuture = future
        future.addListener({
            try {
                controller = future.get()
                controller?.addListener(playerListener)
                updateUi()
            } catch (_: Exception) {
                Toast.makeText(this, "No se pudo conectar con el reproductor.", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun updateUi() {
        val player = controller ?: return
        val metadata = player.currentMediaMetadata
        title.text = metadata.title?.toString()?.takeIf { it.isNotBlank() } ?: "Pista desconocida"
        artist.text = metadata.artist?.toString()?.takeIf { it.isNotBlank() } ?: "Artista desconocido"
        playPause.text = if (player.isPlaying) "Ⅱ" else "▶"
        shuffle.text = if (player.shuffleModeEnabled) "⤨" else "⤨"
        shuffle.alpha = if (player.shuffleModeEnabled) 1f else 0.65f
        repeat.text = when (player.repeatMode) {
            Player.REPEAT_MODE_ONE -> "↻¹"
            Player.REPEAT_MODE_ALL -> "↻"
            else -> "↻"
        }
        repeat.alpha = if (player.repeatMode == Player.REPEAT_MODE_OFF) 0.65f else 1f
        val id = player.currentMediaItem?.mediaId?.toLongOrNull()
        val liked = id != null && MusicPreferences.isFavorite(this, id)
        favorite.text = if (liked) "♥" else "♡"
        favorite.setTextColor(if (liked) 0xFFFF706D.toInt() else Color.WHITE)
        val path = metadata.artworkUri?.path
        ArtworkLoader.load(artwork, path)
        updateBackground(path)
        updatePlaybackProgress()
    }

    private fun updatePlaybackProgress() {
        val player = controller ?: return
        val length = player.duration.takeIf { it > 0L && it != androidx.media3.common.C.TIME_UNSET } ?: 0L
        val position = player.currentPosition.coerceAtLeast(0L)
        duration.text = TimeFormatter.format(length)
        if (!userSeeking) {
            seekBar.max = length.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
            seekBar.progress = position.coerceAtMost(seekBar.max.toLong()).toInt()
            elapsed.text = TimeFormatter.format(position)
        }
    }

    private fun updateBackground(path: String?) {
        if (path.isNullOrBlank()) {
            root.background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(35, 21, 11), Color.rgb(44, 22, 30), Color.BLACK)
            )
            return
        }
        Thread {
            val bitmap = try { BitmapFactory.decodeFile(path) } catch (_: Exception) { null }
            val swatchColor = bitmap?.let {
                try {
                    Palette.from(it).generate().darkVibrantSwatch?.rgb
                        ?: Palette.from(it).generate().dominantSwatch?.rgb
                } catch (_: Exception) { null }
            }
            val color = swatchColor ?: Color.rgb(78, 39, 17)
            val dark = darken(color, 0.42f)
            val darker = darken(color, 0.2f)
            runOnUiThread {
                root.background = GradientDrawable(
                    GradientDrawable.Orientation.TL_BR,
                    intArrayOf(darker, dark, Color.BLACK)
                )
            }
        }.start()
    }

    private fun darken(color: Int, factor: Float): Int {
        return Color.rgb(
            (Color.red(color) * factor).toInt().coerceIn(0, 255),
            (Color.green(color) * factor).toInt().coerceIn(0, 255),
            (Color.blue(color) * factor).toInt().coerceIn(0, 255)
        )
    }

    private fun togglePlayback() {
        controller?.let {
            if (it.isPlaying) it.pause() else it.play()
            updateUi()
        }
    }

    private fun toggleShuffle() {
        controller?.let {
            it.shuffleModeEnabled = !it.shuffleModeEnabled
            updateUi()
        }
    }

    private fun toggleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
            updateUi()
        }
    }

    private fun toggleFavorite() {
        val id = controller?.currentMediaItem?.mediaId?.toLongOrNull() ?: return
        val liked = MusicPreferences.toggleFavorite(this, id)
        favorite.text = if (liked) "♥" else "♡"
        favorite.setTextColor(if (liked) 0xFFFF706D.toInt() else Color.WHITE)
    }

    private fun adjustVolume() {
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
    }

    private fun openEqualizer() {
        try {
            val intent = Intent(AudioEffect.ACTION_DISPLAY_AUDIO_EFFECT_CONTROL_PANEL).apply {
                putExtra(AudioEffect.EXTRA_PACKAGE_NAME, packageName)
                putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MUSIC)
            }
            startActivity(intent)
        } catch (_: Exception) {
            AlertDialog.Builder(this)
                .setTitle("Ecualizador")
                .setMessage("Este teléfono no ofrece un panel de ecualizador compatible para ẞetaMusic. La disponibilidad depende del fabricante y del sistema de audio.")
                .setPositiveButton("Cerrar", null).show()
        }
    }

    private fun showMore(anchor: View) {
        PopupMenu(this, anchor).apply {
            menu.add(if (controller?.shuffleModeEnabled == true) "Desactivar aleatorio" else "Activar aleatorio")
            menu.add("Cambiar repetición")
            menu.add("Información de la pista")
            setOnMenuItemClickListener { item ->
                when (item.title.toString()) {
                    "Desactivar aleatorio", "Activar aleatorio" -> toggleShuffle()
                    "Cambiar repetición" -> toggleRepeat()
                    else -> {
                        val metadata = controller?.currentMediaMetadata
                        AlertDialog.Builder(this@PlayerActivity)
                            .setTitle(metadata?.title?.toString() ?: "Pista")
                            .setMessage("Artista: ${metadata?.artist ?: "Desconocido"}\nÁlbum: ${metadata?.albumTitle ?: "Desconocido"}")
                            .setPositiveButton("Cerrar", null).show()
                    }
                }
                true
            }
            show()
        }
    }

    private fun showPlaylistChooser() {
        val id = controller?.currentMediaItem?.mediaId?.toLongOrNull() ?: return
        val names = MusicPreferences.playlistNames(this)
        if (names.isEmpty()) {
            val input = android.widget.EditText(this).apply { hint = "Nombre de la lista" }
            AlertDialog.Builder(this).setTitle("Crear lista")
                .setView(input)
                .setPositiveButton("Crear") { _, _ ->
                    val name = input.text?.toString().orEmpty()
                    if (MusicPreferences.createPlaylist(this, name)) {
                        MusicPreferences.addToPlaylist(this, name.trim(), id)
                        Toast.makeText(this, "Lista creada y pista añadida", Toast.LENGTH_SHORT).show()
                    } else Toast.makeText(this, "No se pudo crear la lista.", Toast.LENGTH_SHORT).show()
                }.setNegativeButton("Cancelar", null).show()
            return
        }
        AlertDialog.Builder(this).setTitle("Añadir a lista")
            .setItems(names.toTypedArray()) { _, which ->
                MusicPreferences.addToPlaylist(this, names[which], id)
                Toast.makeText(this, "Añadida a ${names[which]}", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun showQueueDialog() {
        val player = controller ?: return
        if (player.mediaItemCount == 0) return
        val entries = (0 until player.mediaItemCount).map { index ->
            val item = player.getMediaItemAt(index)
            val songTitle = item.mediaMetadata.title?.toString() ?: item.mediaId
            val songArtist = item.mediaMetadata.artist?.toString().orEmpty()
            if (index == player.currentMediaItemIndex) "▶  $songTitle — $songArtist" else "$songTitle — $songArtist"
        }
        AlertDialog.Builder(this).setTitle("Cola de reproducción")
            .setItems(entries.toTypedArray()) { _, which ->
                player.seekToDefaultPosition(which)
                player.play()
            }.setPositiveButton("Cerrar", null).show()
    }

    override fun onStop() {
        handler.removeCallbacks(progressTask)
        super.onStop()
    }

    override fun onStart() {
        super.onStart()
        handler.removeCallbacks(progressTask)
        handler.post(progressTask)
    }

    override fun onDestroy() {
        controller?.removeListener(playerListener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
        super.onDestroy()
    }
}
