package studio.beta.music

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class TrackAdapter(
    private val onSelect: (Int) -> Unit,
    private val onMore: (MusicTrack, View) -> Unit
) : RecyclerView.Adapter<TrackAdapter.TrackHolder>() {
    private var items: List<MusicTrack> = emptyList()

    fun submit(items: List<MusicTrack>) {
        this.items = items
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TrackHolder =
        TrackHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_track, parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: TrackHolder, position: Int) {
        val track = items[position]
        holder.title.text = track.title
        holder.artist.text = track.artist.ifBlank { "Artista desconocido" }
        ArtworkLoader.load(holder.artwork, track.artworkPath)
        holder.itemView.setOnClickListener { onSelect(holder.bindingAdapterPosition.coerceAtLeast(0)) }
        holder.more.setOnClickListener { onMore(track, holder.more) }
    }

    class TrackHolder(view: View) : RecyclerView.ViewHolder(view) {
        val artwork: ImageView = view.findViewById(R.id.trackArtwork)
        val title: TextView = view.findViewById(R.id.trackTitle)
        val artist: TextView = view.findViewById(R.id.trackArtist)
        val more: TextView = view.findViewById(R.id.trackMore)
    }
}
